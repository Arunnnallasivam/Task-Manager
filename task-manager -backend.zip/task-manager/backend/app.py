from flask import Flask, request, jsonify
from flask_mysqldb import MySQL
from flask_cors import CORS

app = Flask(__name__)
CORS(app)  # Enable Cross-Origin Resource Sharing for frontend communication

# Database Configuration
# app.config['MYSQL_HOST'] = 'localhost'
# app.config['MYSQL_USER'] = 'root'  # Default XAMPP MySQL user
# app.config['MYSQL_PASSWORD'] = ''  # No password by default
# app.config['MYSQL_DB'] = 'task_db'

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'task_ db'

mysql = MySQL(app)

mysql = MySQL(app)

# API: Create/Add a new task
@app.route('/tasks', methods=['POST'])
def add_task():
    data = request.get_json()
    title = data['title']
    description = data['description']
    cursor = mysql.connect().cursor()
    cursor.execute('INSERT INTO tasks (title, description) VALUES (%s, %s)', (title, description))
    mysql.connect().commit()
    cursor.close()
    return jsonify({'message': 'Task created successfully'}), 201

# API: Retrieve a task by its ID
@app.route('/tasks/<int:id>', methods=['GET'])
def get_task(id):
    cursor = mysql.connect().cursor()
    cursor.execute('SELECT * FROM tasks WHERE id = %s', (id,))
    task = cursor.fetchone()
    cursor.close()
    if task:
        return jsonify({'id': task[0], 'title': task[1], 'description': task[2], 'completed': task[3]})
    else:
        return jsonify({'message': 'Task not found'}), 404

# API: Retrieve a list of all tasks
@app.route('/tasks', methods=['GET'])
def get_all_tasks():
    cursor = mysql.connect().cursor()
    cursor.execute('SELECT * FROM tasks')
    tasks = cursor.fetchall()
    cursor.close()
    task_list = []
    for task in tasks:
        task_list.append({'id': task[0], 'title': task[1], 'description': task[2], 'completed': task[3]})
    return jsonify(task_list)

# API: Update an existing task
@app.route('/tasks/<int:id>', methods=['PUT'])
def update_task(id):
    data = request.get_json()
    title = data['title']
    description = data['description']
    completed = data['completed']
    cursor = mysql.connect().cursor()
    cursor.execute('UPDATE tasks SET title = %s, description = %s, completed = %s WHERE id = %s',
                   (title, description, completed, id))
    mysql.connect().commit()
    cursor.close()
    return jsonify({'message': 'Task updated successfully'})

# API: Delete a task by its ID
@app.route('/tasks/<int:id>', methods=['DELETE'])
def delete_task(id):
    cursor = mysql.connect().cursor()
    cursor.execute('DELETE FROM tasks WHERE id = %s', (id,))
    mysql.connect().commit()
    cursor.close()
    return jsonify({'message': 'Task deleted successfully'}), 200

if __name__ == '__main__':
    app.run(debug=True)
